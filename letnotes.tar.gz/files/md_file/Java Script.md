# Java Script Report

## Table of Contents
1. Variables and Data Types
2. Control Flow
3. Functions
4. Objects
5. Arrays
6. Scope and Closures
7. Asynchronous Programming (Promises/Async/Await)
8. Error Handling (Try/Catch)
9. Modules (Import/Export)
10. DOM Manipulation
11. ES6 Features (Destructuring/Spread)
12. Type Coercion

# Variables and Data Types in JavaScript

## 1. Introduction to Variables

A variable is a named storage location used to hold data in a program. In JavaScript, variables are fundamental for storing values that can be referenced and manipulated.

### 1.1 Why Variables are Essential

*   **Data Storage:** They allow programs to store information (numbers, text, true/false states).
*   **Reusability:** They enable the reuse of data within the code.
*   **Dynamic Nature:** JavaScript is dynamically typed, meaning the type of a variable is determined at runtime, not compile time.

## 2. JavaScript Data Types

Data types define the kind of value a variable can hold and what operations can be performed on that value. JavaScript data types are broadly categorized into Primitive and Non-Primitive types.

### 2.1 Primitive Data Types

Primitive types are values that are stored directly by the variable. They are immutable (their values cannot be changed) and are stored by value.

#### 2.1.1 String (`string`)
Represents sequences of characters (text). Strings are immutable.
*   **Example:** `"Hello World"`, `'JavaScript'`

#### 2.1.2 Number (`number`)
Represents both integers and floating-point numbers. JavaScript uses a 64-bit floating-point format for all numbers.
*   **Example:** `10`, `3.14159`, `NaN` (Not a Number)

#### 2.1.3 Boolean (`boolean`)
Represents logical entity, having only two possible values: `true` or `false`.
*   **Example:** `true`, `false`

#### 2.1.4 Null (`null`)
Represents the intentional absence of any object value or a value that has no value. It is an assignment value.
*   **Example:** `let data = null;`

#### 2.1.5 Undefined (`undefined`)
Represents the value of a variable that has been declared but has not yet been assigned a value.
*   **Example:** `let x;` (x is undefined)

#### 2.1.6 Symbol (`symbol`)
Introduced in ES6, used to create unique and immutable values, often used as keys for object properties.
*   **Example:** `Symbol('id')`

#### 2.1.7 BigInt (`bigint`)
Used for representing integers that are larger than $2^{53} - 1$, allowing for arbitrary precision integers.
*   **Example:** `12345678901234567890n`

### 2.2 Non-Primitive (Reference) Data Types

Non-primitive types are complex data structures. They are mutable (their contents can be changed) and are stored by reference (the variable stores the memory address of the value).

#### 2.2.1 Object (`object`)
The most complex type in JavaScript. Objects are collections of key-value pairs. Everything in JavaScript is an object, including Arrays and Functions.
*   **Example:** `let person = { name: "Alice", age: 30 };`

#### 2.2.2 Array (`array`)
A special type of object used to store ordered lists of values. Arrays are mutable.
*   **Example:** `let colors = ["Red", "Green", "Blue"];`

#### 2.2.3 Function (`function`)
Functions are blocks of reusable code that can be treated as first-class objects.
*   **Example:** `function greet() { return "Hello"; }`

## 3. Variable Declaration Methods

JavaScript offers three primary ways to declare variables, each with specific implications regarding scope and mutability.

### 3.1 `var` (Legacy)

*   **Scope:** Function-scoped. Variables declared with `var` are accessible within the entire function where they are defined.
*   **Hoisting:** Variables are hoisted (but initialized with `undefined`).
*   **Issue:** `var` is prone to problems in complex nested loops and blocks due to its function-scoping behavior.

```javascript
var x = 10;
function example() {
    var x = 20; // This redefines the outer x in non-block scope
    console.log(x); // Output: 20
}
```

### 3.2 `let` (Modern Standard)

*   **Scope:** Block-scoped. Variables declared with `let` are restricted to the block (defined by curly braces `{}`) in which they are declared.
*   **Hoisting:** Hoisted, but not initialized. Accessing them before declaration results in a `ReferenceError` (Temporal Dead Zone).
*   **Mutability:** Mutable (can be reassigned).

```javascript
let y = 10;
if (true) {
    let y = 20; // This is a new variable scoped only to the if block
    console.log(y); // Output: 20
}
console.log(y); // Output: 10
```

### 3.3 `const` (Modern Standard for Immutability)

*   **Scope:** Block-scoped (same as `let`).
*   **Hoisting:** Hoisted, but not initialized.
*   **Mutability:** Immutable. Variables declared with `const` must be initialized upon declaration and cannot be reassigned later.
*   **Note on Objects/Arrays:** While the variable reference itself is constant (`const`), the *contents* of objects and arrays declared with `const` are still mutable.

```javascript
const PI = 3.14159;
// PI = 3.14; // ERROR: Assignment to constant variable.

const user = { name: "Bob" };
user.name = "Robert"; // Allowed: Contents of the object are mutable
// user = { name: "Charlie" }; // ERROR: Cannot reassign the variable reference
```

## 4. Advanced Concepts

### 4.1 Type Coercion

Type coercion is the process where JavaScript automatically converts values from one data type to another during an operation. This conversion can lead to unexpected results if not handled carefully.

*   **Implicit Coercion:** Automatic conversion performed by the JS engine (e.g., comparing a string and a number).
    *   *Example:* `5 + "5"` results in `"55"` (string concatenation).
*   **Explicit Coercion:** Intentional conversion performed by the programmer (e.g., using `Number()`, `String()`, or `parseInt()`).

### 4.2 Immutability vs. Mutability

*   **Immutable:** A value cannot be changed after creation (e.g., Strings, Numbers, `const`). This aids in writing predictable and safer code.
*   **Mutable:** A value can be modified after creation (e.g., Arrays, Objects, variables declared with `let`).

## 5. Best Practices

1.  **Prefer `const` by Default:** Use `const` for all variables unless you explicitly know the value needs to be reassigned. This promotes immutability and improves code predictability.
2.  **Use `let` Sparingly:** Reserve `let` for variables that are expected to change their value, such as loop counters or variables that track state.
3.  **Avoid `var`:** Do not use `var` in modern JavaScript code. Use `let` or `const` instead to benefit from true block-scoping and avoid common scope-related bugs.
4.  **Handle Null and Undefined:** Always check for `null` and `undefined` when dealing with external data or function return values to prevent runtime errors.
5.  **Understand Reference vs. Value:** Remember that primitive types are stored by value, while non-primitive types (objects) are stored by reference. Changes to an object modify the object itself, not the reference pointer.

# Control Flow in JavaScript

## 1. Introduction to Control Flow

Control flow refers to the order in which instructions are executed within a program. In JavaScript, control flow dictates the path that the execution thread takes, allowing programs to make decisions, repeat actions, and manage the sequence of operations.

Understanding control flow is fundamental to writing logical, efficient, and readable JavaScript code.

**Why is Control Flow Important?**
*   **Decision Making:** Allowing the program to execute different blocks of code based on specific conditions.
*   **Iteration:** Enabling repetitive execution of code blocks (loops).
*   **Efficiency:** Optimizing the execution path to solve a problem effectively.

## 2. Core Control Flow Structures

JavaScript provides several mechanisms to manage the execution path. These mechanisms can be broadly categorized into Conditional Statements and Iteration Structures.

### 2.1. Conditional Statements (Decision Making)

Conditional statements allow the program to execute specific blocks of code only if a certain condition evaluates to `true`.

#### A. `if...else` Statement
Used for executing code based on a single condition.

```javascript
let score = 85;
if (score >= 90) {
    console.log("Grade: A");
} else if (score >= 80) {
    console.log("Grade: B");
} else {
    console.log("Grade: C or lower");
}
```

#### B. `switch` Statement
Used for performing multiple comparisons against a single expression. It is often cleaner than multiple `if...else if` chains when checking discrete values.

```javascript
let day = "Wednesday";
let dayType;

switch (day) {
    case "Monday":
    case "Tuesday":
    case "Wednesday":
        dayType = "Weekday";
        break;
    case "Saturday":
    case "Sunday":
        dayType = "Weekend";
        break;
    default:
        dayType = "Invalid Day";
}

console.log(dayType); // Output: Weekday
```

### 2.2. Iteration Structures (Looping)

Loops allow a set of instructions to be executed repeatedly.

#### A. `for` Loop
The most common loop structure, used when the number of iterations is known. It controls initialization, condition, and increment steps in a single line.

```javascript
// Traditional for loop
for (let i = 0; i < 5; i++) {
    console.log("Iteration number: " + i);
}
// Output: 0, 1, 2, 3, 4
```

#### B. `while` Loop
Executes a block of code as long as a specified condition remains `true`. The condition is checked before each iteration.

```javascript
let count = 0;
while (count < 3) {
    console.log("While loop iteration: " + count);
    count++;
}
```

#### C. `do...while` Loop
Similar to the `while` loop, but guarantees that the code block is executed at least once before the condition is checked.

```javascript
let i = 5;
do {
    console.log("Executed once. i is: " + i);
    i++;
} while (i < 5); // Condition is false, but the loop executed once
```

#### D. Modern Iteration Methods (For Arrays)

For iterating over collections like Arrays and Strings, modern methods offer cleaner and safer control flow.

*   **`for...of` Loop:** Used for iterating over the values of iterable objects (like Arrays).
    ```javascript
    const colors = ["red", "green", "blue"];
    for (const color of colors) {
        console.log(color);
    }
    ```
*   **`for...in` Loop:** Used for iterating over the enumerable properties (keys) of an object.
    ```javascript
    const person = { name: "Alice", age: 30 };
    for (const key in person) {
        console.log(`${key}: ${person[key]}`);
    }
    ```

## 3. Flow Control Keywords

These keywords are used *inside* loops or conditional blocks to modify the standard execution path.

### 3.1. `break` Statement
Immediately terminates the execution of the current loop (or switch) and transfers control to the statement following the loop.

```javascript
for (let i = 0; i < 10; i++) {
    if (i === 5) {
        break; // Stop the loop when i reaches 5
    }
    console.log(i); // Output: 0, 1, 2, 3, 4
}
```

### 3.2. `continue` Statement
Skips the current iteration of the loop and proceeds immediately to the next iteration.

```javascript
for (let i = 0; i < 5; i++) {
    if (i % 2 === 0) {
        continue; // Skip even numbers
    }
    console.log(i); // Output: 1, 3
}
```

### 3.3. `return` Statement
Used within a function to exit the function and optionally return a value to the caller. This is crucial for controlling the flow of execution within procedural code.

```javascript
function checkAge(age) {
    if (age < 18) {
        return "Access Denied"; // Exit the function immediately
    }
    // Code below only runs if the return condition is not met
    return "Access Granted";
}

console.log(checkAge(16)); // Output: Access Denied
```

## 4. Advanced Control Flow (Asynchronous Operations)

In modern JavaScript, control flow also involves managing asynchronous operations, where the execution path is determined by the completion of external operations.

### Asynchronous Flow (`Promises` and `async/await`)
*   **Promises:** Objects representing the eventual completion (or failure) of an asynchronous operation. Control flow is managed by chaining methods (`.then()`, `.catch()`) to handle the results sequentially.
*   **`async/await`:** Syntactic sugar built on top of Promises, allowing asynchronous code to be written in a synchronous-looking manner, greatly simplifying complex control flow.

```javascript
async function fetchData() {
    try {
        console.log("Starting data fetch...");
        // Execution pauses here until the Promise resolves
        const response = await fetch('api/data');
        const data = await response.json();
        console.log("Data successfully retrieved.");
        return data;
    } catch (error) {
        console.error("An error occurred:", error);
    }
}

fetchData();
```

## 5. Best Practices for Control Flow

### 5.1. Prioritize Readability
*   **Minimize Nesting:** Deeply nested `if` statements and loops make code extremely difficult to follow and debug. Use early exits (like `return` or `break`) to flatten the structure.
*   **Descriptive Conditions:** Use clear, meaningful variable names and logical expressions to define conditions.

### 5.2. Choose the Right Loop
*   **Use `for` Loops:** When you know the exact number of iterations.
*   **Use `while` Loops:** When the number of iterations is unknown, and the loop depends on a condition that changes dynamically.
*   **Use Array Methods:** For iterating over collections, prefer `for...of` (for values) or `.map()`, `.filter()`, and `.reduce()` over manual index-based `for` loops where possible, as they manage the flow implicitly.

### 5.3. Handle Edge Cases and Errors
*   **Defensive Programming:** Always check for null, undefined, or empty values before attempting to iterate or access properties, preventing runtime errors.
*   **Use `try...catch`:** For operations that involve external resources (like network requests), always wrap them in `try...catch` blocks to gracefully handle flow interruptions.

### 5.4. Avoid Infinite Loops
Be extremely careful when designing loops. An infinite loop (where the exit condition is never met) can freeze the program. Always ensure that the loop variable is properly updated to eventually reach the exit condition.

# Functions in JavaScript: A Comprehensive Report

## 1. Introduction to JavaScript Functions

A function in JavaScript is a block of code designed to perform a specific task. Functions are the fundamental building blocks of any JavaScript program, allowing developers to organize code, promote reusability, and manage complexity.

In JavaScript, functions are first-class citizens, meaning they can be treated like any other value: they can be passed as arguments to other functions, returned from other functions, and assigned to variables.

## 2. Defining and Declaring Functions

There are several ways to define a function in JavaScript, each with slightly different syntactic behaviors.

### 2.1. Function Declarations (Function Statements)

This is the traditional way to define a function. Declarations are "hoisted," meaning the function can be called before it is defined in the code.

```javascript
// Function Declaration
function add(a, b) {
  return a + b;
}

console.log(add(5, 10)); // Output: 15
```

### 2.2. Function Expressions

A function expression involves defining a function and assigning it to a variable.

```javascript
// Function Expression
const multiply = function(a, b) {
  return a * b;
};

console.log(multiply(5, 10)); // Output: 50
```

### 2.3. Arrow Functions (ES6+)

Arrow functions provide a more concise syntax for writing functions, particularly useful for short, anonymous functions, and they handle the `this` binding differently.

```javascript
// Arrow Function (Standard Syntax)
const subtract = (a, b) => {
  return a - b;
};

console.log(subtract(10, 3)); // Output: 7
```

#### Concise Arrow Function Syntax

For functions with a single expression, the syntax can be simplified:

```javascript
// Single Expression Arrow Function
const square = x => x * x;

console.log(square(4)); // Output: 16
```

## 3. Parameters, Arguments, and Return Values

### 3.1. Parameters vs. Arguments

*   **Parameters:** The variables listed inside the parentheses in the function definition (placeholders).
*   **Arguments:** The actual values passed to the function when it is called.

### 3.2. The `return` Statement

The `return` statement is used to exit a function and pass a value back to the caller. If a function does not explicitly use `return`, it implicitly returns `undefined`.

```javascript
function greet(name) {
  return "Hello, " + name + "!";
}

let message = greet("Alice");
console.log(message); // Output: Hello, Alice!
```

## 4. Scope, Closures, and Hoisting

### 4.1. Scope

Scope defines the accessibility of variables. In JavaScript, variables defined within a function are locally scoped (function scope).

### 4.2. Closures

A closure is a function bundled together with references to its surrounding state (the lexical environment). Closures allow an inner function to access variables from its outer (enclosing) function, even after the outer function has finished executing.

**Example of Closure:**

```javascript
function createCounter() {
  let count = 0; // This is the private state
  return function increment() {
    count++; // Inner function accesses the outer function's variable
    return count;
  };
}

const counter = createCounter();
console.log(counter()); // Output: 1
console.log(counter()); // Output: 2
```

### 4.3. Hoisting

Hoisting is JavaScript's behavior of moving function declarations to the top of their scope during the compilation phase.

*   **Function Declarations:** Are fully hoisted, allowing calls before definition.
*   **Function Expressions:** Are not fully hoisted (only the variable declaration is hoisted), meaning you cannot call an expression before it is assigned.

## 5. The `this` Keyword in Functions

The value of the `this` keyword is context-dependent in JavaScript, meaning its value changes based on how the function is called (e.g., in object methods, callbacks, or standalone calls).

*   **In Object Methods:** `this` refers to the object the method is called on.
*   **In Arrow Functions:** Arrow functions do not have their own `this` binding; they inherit `this` from the surrounding lexical scope. This makes them excellent for maintaining consistent context in callbacks.

## 6. Best Practices for Writing Functions

### 6.1. Readability and Naming

*   **Use Descriptive Names:** Function names should clearly describe what the function does (e.g., `calculateTotal()` instead of `calc()`).
*   **Use Camel Case:** Follow standard JavaScript naming conventions (e.g., `myFunctionName`).

### 6.2. Single Responsibility Principle (SRP)

Functions should ideally perform one task and do it well. Avoid writing overly long, monolithic functions.

### 6.3. Avoid Side Effects

Functions should aim to be pure wherever possible. A pure function is one that, given the same input, will always return the same output and causes no observable side effects (modifying global state, performing I/O).

**Impure Example (Side Effect):**

```javascript
let total = 0;
function addToTotal(value) {
  total += value; // Modifying external state (Side Effect)
  return total;
}
```

**Pure Example (No Side Effect):**

```javascript
function add(a, b) {
  return a + b; // Only depends on inputs, returns a result
}
```

### 6.4. Use Rest and Spread Operators

*   **Rest Parameter (`...`):** Used to collect an indefinite number of arguments into an array.
*   **Spread Operator (`...`):** Used to expand an iterable (like an array) into individual elements when calling a function or creating a new array.

## 7. Practical Example: Array Manipulation

This example demonstrates how functions are used to process data.

```javascript
// 1. Function using arrow syntax to process an array
const calculateAverage = (numbers) => {
  if (numbers.length === 0) {
    return 0;
  }
  // Use the reduce method for efficient summation
  const sum = numbers.reduce((accumulator, currentValue) => accumulator + currentValue, 0);
  return sum / numbers.length;
};

// 2. Function to perform a side effect (for comparison)
const logNumbers = (numbers) => {
    console.log("Numbers:", numbers);
};

const data = [10, 20, 30, 40];

// Calling the pure function
const average = calculateAverage(data);
console.log("The average is:", average); // Output: The average is: 25

// Calling the side-effect function
logNumbers(data); // Output: Numbers: [10, 20, 30, 40]
```

# Objects in JavaScript: A Comprehensive Report

## 1. Introduction to JavaScript Objects

An Object in JavaScript is a fundamental data structure used to store collections of data and functionality. Objects are reference types, meaning they store memory addresses (references) rather than the actual data itself. They are the backbone of Object-Oriented Programming (OOP) in JavaScript, allowing developers to model real-world entities and manage complex data structures.

## 2. Key Concepts

### 2.1. Object Definition

An object is a collection of **properties** (key-value pairs).

*   **Property:** A characteristic or attribute of the object, defined by a name (key) and a value.
*   **Value:** The data associated with the property.

### 2.2. Object Creation Methods

There are three primary ways to create objects in JavaScript:

#### A. Object Literal Notation (Most Common)
This is the simplest and most idiomatic way to create an object.

```javascript
const car = {
    make: "Toyota",
    model: "Camry",
    year: 2022,
    isElectric: false,
    // Methods can also be defined here
    startEngine: function() {
        console.log("Engine started.");
    }
};
```

#### B. Constructor Function (Pre-ES6 Method)
This method uses a function that acts as a blueprint for creating objects.

```javascript
function Dog(name, breed) {
    this.name = name;
    this.breed = breed;
}

const myDog = new Dog("Buddy", "Golden Retriever");
console.log(myDog.name); // Output: Buddy
```

#### C. ES6 Classes (Syntactic Sugar over Prototypes)
Classes provide a cleaner, more structured syntax for creating objects and managing inheritance.

```javascript
class Animal {
    constructor(name) {
        this.name = name;
    }
    speak() {
        console.log(`${this.name} makes a sound.`);
    }
}

const lion = new Animal("Leo");
lion.speak(); // Output: Leo makes a sound.
```

### 2.3. Properties vs. Methods

*   **Properties:** Data associated with the object (e.g., `car.make`). They hold values.
*   **Methods:** Functions stored as properties within an object. They define the behavior or actions that the object can perform (e.g., `car.startEngine()`).

### 2.4. The Prototype Chain and Inheritance

JavaScript uses prototypal inheritance. Every object has an internal link to another object, called its prototype. When you try to access a property on an object, if it doesn't exist directly on the object, JavaScript looks up the prototype chain to find it.

*   **`__proto__`:** A non-standard property used to access the internal `[[Prototype]]` link of an object. (Generally avoided in favor of `Object.getPrototypeOf()`).
*   **Prototype Chain:** The sequence of objects linked together via the `[[Prototype]]` link. When traversing this chain, JavaScript searches for properties.

**Example of Inheritance:**

```javascript
function Vehicle(wheels) {
    this.wheels = wheels;
}

function Car(wheels, color) {
    // Call the parent constructor
    Vehicle.call(this, wheels);
    this.color = color;
}

// Set the prototype of Car to Vehicle
Car.prototype = Object.create(Vehicle.prototype);
Car.prototype.constructor = Car;

const myCar = new Car(4, "Red");
console.log(myCar.wheels); // Inherited from Vehicle: 4
console.log(myCar.color);   // Specific to Car: Red
```

## 3. Object Manipulation Techniques

### 3.1. Accessing Properties

Objects can be accessed using two primary methods:

*   **Dot Notation (`.`):** Preferred for simple property access.
    ```javascript
    console.log(car.make);
    ```
*   **Bracket Notation (`[]`):** Necessary when the property name is stored in a variable, or when the property name contains special characters.
    ```javascript
    const propName = "model";
    console.log(car[propName]); // Accesses car.model
    ```

### 3.2. Modifying Object State (Mutability)

Objects are mutable, meaning their properties can be changed after creation.

```javascript
const user = { name: "Alice", age: 30 };

// Modifying a property
user.age = 31;

// Adding a new property
user.city = "New York";

console.log(user); // { name: 'Alice', age: 31, city: 'New York' }
```

### 3.3. Advanced Manipulation (Spread Operator and Destructuring)

ES6 features simplify object manipulation:

*   **Spread Operator (`...`):** Used to copy properties or merge objects easily.
    ```javascript
    const base = { color: "blue" };
    const car = { ...base, make: "Honda" }; // Merges 'color' and adds 'make'
    ```
*   **Destructuring Assignment:** Allows extracting properties from an object into distinct variables.
    ```javascript
    const product = { id: 101, name: "Laptop", price: 1200 };
    const { name, price } = product; // name is "Laptop", price is 1200
    ```

## 4. Best Practices for JavaScript Objects

### 4.1. Favor Immutability Where Possible

When dealing with complex state, strive to make objects immutable (unchangeable). This prevents unintended side effects across different parts of the application.

*   **Mutable Example (Avoid for state management):**
    `user.age = 32;`
*   **Immutable Approach (Preferred):** Create a new object with the updated values.
    ```javascript
    const user = { name: "Alice", age: 30 };
    const updatedUser = { ...user, age: 32 }; // Creates a new object
    ```

### 4.2. Use Classes for Complex Structures

For large, structured objects requiring complex inheritance and standardized methods, use ES6 `class` syntax instead of manual prototype manipulation.

### 4.3. Encapsulation via Private Fields (Modern Approach)

While traditional JavaScript objects do not enforce true private members, modern JS (ES2020+) allows the use of `#` prefixes to define truly private fields, enforcing encapsulation within the class scope.

```javascript
class Account {
    #balance; // Private field

    constructor(initialBalance) {
        this.#balance = initialBalance;
    }

    deposit(amount) {
        this.#balance += amount;
    }

    getBalance() {
        return this.#balance;
    }
}

const account = new Account(1000);
// console.log(account.#balance); // Error: Cannot access private field
account.deposit(500);
console.log(account.getBalance()); // Output: 1500
```

## 5. Practical Example: Simulating a Store Inventory

This example demonstrates object creation, method definition, and object manipulation.

```javascript
// 1. Object Creation using Object Literal
const inventory = {
    productID: "P1001",
    name: "Wireless Mouse",
    price: 25.99,
    stock: 50,
    isAvailable: true,

    // 2. Method Definition (Behavior)
    checkStock: function() {
        if (this.stock > 0) {
            return `In stock: ${this.stock} units.`;
        } else {
            return "Out of stock.";
        }
    },

    // 3. Mutator Method (Modifies the object state)
    sellItem: function(quantity) {
        if (this.stock >= quantity) {
            this.stock -= quantity;
            return `Sold ${quantity} units. Remaining stock: ${this.stock}.`;
        } else {
            return `Error: Insufficient stock. Only ${this.stock} available.`;
        }
    }
};

console.log("--- Initial Inventory ---");
console.log(inventory);

// Accessing Data (Dot Notation)
console.log(`Product: ${inventory.name}`);

// Calling a Method
console.log("\n--- Stock Check ---");
console.log(inventory.checkStock());

// Modifying the State (Mutating the object)
console.log("\n--- Selling Items ---");
const result = inventory.sellItem(10);
console.log(result);

// Checking the updated stock
console.log(`\nUpdated Inventory Status: ${inventory.checkStock()}`);
console.log(inventory);
```

# Report: Arrays in JavaScript

## 1. Introduction to JavaScript Arrays

An Array in JavaScript is a fundamental, built-in data structure used to store an ordered collection of values. Arrays are used to manage lists of data, allowing developers to store multiple items under a single variable name.

### 1.1 Definition and Characteristics

*   **Ordered Collection:** Elements are stored in a specific sequence.
*   **Zero-Indexing:** Elements are accessed using an index starting from 0 (the first element is at index 0).
*   **Heterogeneous:** JavaScript arrays can store values of different data types (numbers, strings, objects, booleans, etc.).
*   **Reference Type:** Arrays are objects; variables holding array references point to the same memory location, meaning operations on one reference affect all references.
*   **Dynamic Size:** Arrays can grow or shrink in size dynamically during execution.

## 2. Array Creation and Initialization

There are several ways to create arrays in JavaScript.

### 2.1 Literal Notation (Recommended)

This is the most common and simplest way to create an array.

```javascript
// Array of numbers
let numbers = [10, 20, 30, 40];

// Array of strings
let fruits = ["Apple", "Banana", "Cherry"];

// Mixed array (heterogeneous)
let mixed = [1, "two", true, { a: 1 }];
```

### 2.2 Using the `Array` Constructor

This method is useful for creating arrays with a predefined length.

```javascript
// Create an empty array
let emptyArray = new Array();

// Create an array of a specific length (initializes elements to 'empty' slots)
let arrOfFive = new Array(5); // [empty × 5]

// Create an array of N zeros
let zeros = new Array(5).fill(0); // [0, 0, 0, 0, 0]
```

### 2.3 Creating Arrays from Iterables

Methods like `Array.from()`, `map()`, or the spread syntax (`...`) are powerful for creating arrays based on existing data structures.

```javascript
// Creating an array from an iterable (e.g., a string)
let letters = [...String.fromCharCode(65), ...String.fromCharCode(66), ...]; // ['A', 'B', ...]

// Creating a new array of a specific size
let newArray = Array(10).fill(null); // [null, null, null, ..., null]
```

## 3. Accessing Array Elements

Elements in an array are accessed using their zero-based index within square brackets `[]`.

```javascript
let colors = ["Red", "Green", "Blue"];

// Accessing the first element (index 0)
let firstColor = colors[0]; // "Red"

// Accessing the third element (index 2)
let thirdColor = colors[2]; // "Blue"

// Accessing elements using index comparison
let secondColor = colors[1]; // "Green"
```

## 4. Modifying Arrays (Mutating Operations)

Array methods are used to add, remove, and change elements, thus modifying the array in place.

### 4.1 Adding Elements

| Method | Description | Example |
| :--- | :--- | :--- |
| **`push()`** | Adds one or more elements to the end of the array. | `arr.push(40);` |
| **`pop()`** | Removes the last element and returns it. | `arr.pop();` |
| **`unshift()`** | Adds one or more elements to the beginning of the array. | `arr.unshift(0);` |
| **`shift()`** | Removes the first element and returns it. | `arr.shift();` |

**Example:**
```javascript
let items = [1, 2, 3];
items.push(4);       // items is [1, 2, 3, 4]
items.unshift(0);    // items is [0, 1, 2, 3, 4]
let removed = items.shift(); // removed is 0, items is [1, 2, 3, 4]
```

### 4.2 Removing Elements

| Method | Description | Example |
| :--- | :--- | :--- |
| **`splice()`** | Changes the contents of an array by removing or replacing existing elements. Returns an array of deleted elements. | `arr.splice(start, deleteCount);` |
| **`pop()` / `shift()`** | Used for removing elements from the end or beginning, respectively. | `arr.pop();` |

**Example using `splice()`:**
```javascript
let data = [10, 20, 30, 40, 50];
// Start at index 2, remove 2 elements (30 and 40)
let removedItems = data.splice(2, 2); 

console.log(data);        // [10, 20, 50]
console.log(removedItems); // [30, 40]
```

## 5. Iteration and Transformation

Efficiently processing array elements is crucial. JavaScript offers powerful methods for iteration and functional programming techniques (Higher-Order Functions).

### 5.1 Traditional Loops

#### `for` Loop (Best for performance and control)
```javascript
let numbers = [5, 10, 15];
for (let i = 0; i < numbers.length; i++) {
    console.log(`Element at index ${i}: ${numbers[i]}`);
}
```

#### `for...of` Loop (Best for iterating over values)
```javascript
for (const num of numbers) {
    console.log(num);
}
```

### 5.2 Functional Array Methods (Transformation and Filtering)

These methods are ideal for creating new arrays based on the results of an operation, promoting immutability.

| Method | Purpose | Example |
| :--- | :--- | :--- |
| **`map()`** | Creates a new array by applying a function to every element. | `arr.map(item => item * 2)` |
| **`filter()`** | Creates a new array containing all elements that pass a test implemented by the provided function. | `arr.filter(item => item > 10)` |
| **`reduce()`** | Executes a reducer function on each element to reduce it to a single value. | `arr.reduce((sum, item) => sum + item, 0)` |

**Example using `map()` and `filter()`:**
```javascript
let scores = [85, 45, 92, 30, 78];

// 1. Filter: Get only scores above 50
let passingScores = scores.filter(score => score > 50); // [85, 92, 78]

// 2. Map: Calculate the average of the passing scores
let average = passingScores.reduce((sum, score) => sum + score, 0) / passingScores.length;

console.log("Passing Scores:", passingScores); // [85, 92, 78]
console.log("Average:", average);             // 85.0
```

## 6. Advanced Array Concepts

### 6.1 Nested Arrays

Arrays can contain other arrays, representing multi-dimensional data (like a grid or table).

```javascript
// A 2D array representing a 3x3 matrix
let matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
];

// Accessing an element: [row_index][column_index]
let element = matrix[1][2]; // 6
```

### 6.2 Array of Objects

Arrays are commonly used to store collections of complex data, such as records or entities.

```javascript
let users = [
    { id: 1, name: "Alice", age: 30 },
    { id: 2, name: "Bob", age: 25 },
    { id: 3, name: "Charlie", age: 35 }
];

// Iterating over objects
users.forEach(user => {
    console.log(`${user.name} is ${user.age} years old.`);
});
```

## 7. Best Practices and Performance Considerations

### 7.1 Immutability

**Principle:** Whenever possible, favor creating new arrays rather than modifying existing ones (immutability). This helps prevent unintended side effects, especially in large applications.

*   **Use `map()`, `filter()`, `reduce()`:** These methods return new arrays, leaving the original array untouched.
*   **Avoid excessive use of `splice()`:** While powerful, modifying arrays in place can make debugging complex operations harder.

### 7.2 Time and Space Complexity

| Operation | Time Complexity | Notes |
| :--- | :--- | :--- |
| **Accessing an element** (`arr[i]`) | $O(1)$ (Constant Time) | Extremely fast, regardless of array size. |
| **Searching (Linear Scan)** | $O(n)$ (Linear Time) | Must check every element in the worst case. |
| **Adding/Removing at the end** (`push()`, `pop()`) | $O(1)$ (Constant Time) | Very fast. |
| **Adding/Removing at the beginning** (`shift()`) | $O(n)$ (Linear Time) | Requires shifting all subsequent elements. |
| **Inserting/Deleting in the Middle** (`splice()`) | $O(n)$ (Linear Time) | Requires shifting elements around the insertion point. |

### 7.3 Performance Tips

1.  **For Frequent Lookups:** If you need to look up data by a unique key, consider using a JavaScript **Object** or a **Map** instead of an array, as lookups in objects are typically $O(1)$.
2.  **Avoid Repeated Searches:** If you frequently search an array for a specific value, convert the array into a `Set` first, as Set lookups are also $O(1)$.
3.  **Pre-allocate Space (if known):** If you know the final size of the array, using the `new Array(n).fill(value)` method can be slightly more efficient than repeatedly calling `push()`.

# Scope and Closures in JavaScript: A Detailed Report

## 1. Introduction

Scope and closures are fundamental concepts in JavaScript that dictate how variables are accessed, how code execution flows, and how functions retain access to their surrounding environment. Understanding these concepts is crucial for writing predictable, maintainable, and efficient code, especially when dealing with asynchronous operations and functional programming patterns.

This report details the mechanics of JavaScript scope and the powerful concept of closures, providing key principles, best practices, and practical examples.

## 2. Understanding Scope

Scope defines the accessibility of variables, functions, and objects within different parts of a program. In JavaScript, scope determines whether a specific identifier (like a variable name) can be referenced.

### 2.1. Lexical Scope (The Foundation)

Lexical scope refers to the scope chain created by the text structure of the code. It determines which variables are accessible based on where they are physically defined in the source code.

*   **Definition:** A variable is in scope if it is accessible from the point of reference.
*   **Mechanism:** JavaScript uses lexical scoping, meaning the scope of a variable is determined by where the variable is physically written, not where the function is called.

### 2.2. Types of Scope

JavaScript primarily deals with three types of scope:

#### A. Global Scope
Variables declared outside any function or block are in the global scope. These variables are accessible from anywhere in the program. Accessing global variables should be done sparingly as it can lead to naming collisions.

#### B. Function Scope (Pre-ES6)
In older JavaScript (using `var`), variables declared within a function were scoped to that function. This meant a variable declared inside a function was only accessible within that function.

#### C. Block Scope (ES6+)
With the introduction of `let` and `const`, JavaScript introduced true block scoping. A block is defined by curly braces `{}` (e.g., inside an `if` statement, `for` loop, or a function body). Variables declared with `let` and `const` are limited to the block in which they are defined.

### 2.3. Variable Declaration Keywords: `var`, `let`, and `const`

The choice of keyword dictates the scope and mutability of a variable:

| Keyword | Scope Type | Reassignment | Redeclaration | Hoisting Behavior |
| :--- | :--- | :--- | :--- | :--- |
| `var` | Function/Global | Yes | Yes | Hoisted (initialized to `undefined`) |
| `let` | Block | Yes | No | Hoisted (but inaccessible until declaration - Temporal Dead Zone) |
| `const` | Block | No | No | Hoisted (but inaccessible until declaration - Temporal Dead Zone) |

**Best Practice:** Always favor `const` by default. If you know the variable will need to be reassigned, use `let`. Avoid using `var` in modern JavaScript to prevent scope ambiguities and side effects.

## 3. Closures: Capturing the Environment

A closure is one of the most powerful and fundamental concepts in JavaScript.

### 3.1. Definition of Closure

A closure is the combination of a function bundled together with its surrounding **lexical environment**. In simpler terms, a closure is the ability of an inner function to access the variables of its outer (enclosing) function, even after the outer function has finished executing.

### 3.2. How Closures Work

When an inner function is defined inside an outer function, it forms a closure over the outer function's scope. When the outer function returns the inner function, the inner function maintains a live link to the outer function's variables.

**Mechanism:**
1. The outer function executes and defines local variables.
2. The inner function is returned.
3. The inner function retains access to the variables defined by the outer function, regardless of where the execution continues.

### 3.3. Practical Example of Closure

```javascript
function createCounter() {
    let count = 0; // Variable in the outer scope (lexical environment)

    // The returned function is the closure
    return function increment() {
        count = count + 1; // Accessing and modifying the outer variable
        console.log(count);
    };
}

// 'myCounter' is the closure created when createCounter runs
const myCounter = createCounter();

myCounter(); // Output: 1 (count is 1)
myCounter(); // Output: 2 (count is 2)

// The original createCounter execution is complete, but 'count' persists
// and is only accessible through the returned function (myCounter).
```

## 4. Scope vs. Closures: Key Distinction

While related, scope and closures address different aspects of JavaScript memory and access:

*   **Scope:** Defines *where* a variable can be accessed at any given moment (the rules of access).
*   **Closure:** Defines *how* a function maintains persistent access to a specific scope, even when that scope is no longer directly accessible (the mechanism of retention).

Closures are a *result* of lexical scoping in JavaScript, allowing functions to maintain a persistent reference to their environment.

## 5. Best Practices for Scope and Closures

1.  **Use `let` and `const`:** Always use these block-scoped keywords to eliminate ambiguity and improve code predictability compared to `var`.
2.  **Minimize Global State:** Try to encapsulate data within modules or functions. Relying heavily on global variables creates tight coupling and makes debugging difficult.
3.  **Understand Data Persistence:** Recognize that closures are essential for patterns like currying, event handlers, and creating private state, where functions need to remember specific context over time.
4.  **Avoid Unnecessary Capturing:** Be mindful when passing large objects or arrays into functions that might create long-lived closures, as this can impact memory usage.

## 6. Advanced Example: Closures in Asynchronous Operations

Closures are vital in handling asynchronous operations where state needs to be preserved between execution points.

```javascript
function fetchData(url) {
    let data = null; // State maintained by the closure
    
    // Simulate an asynchronous fetch operation
    setTimeout(() => {
        data = `Data successfully fetched from ${url}`;
        console.log(data);
    }, 1000);
    
    // Return a function that will execute the result later
    return function displayResult() {
        console.log("--- Result Display ---");
        console.log(data); // Accessing the variable 'data' from the outer scope
    };
}

// When we call fetchData, the setTimeout is pending.
const fetchAndDisplay = fetchData('API_Endpoint_1');

// Now we call the returned function. This function creates a closure
// over the 'data' variable, which holds the promise of the result.
fetchAndDisplay.displayResult(); 
// Output (after 1 second): --- Result Display --- Data successfully fetched from API_Endpoint_1
```

## 7. Conclusion

Scope and closures are the structural backbone of complex JavaScript programs. Mastering lexical scoping allows developers to understand variable accessibility, while understanding closures enables the creation of stateful, modular, and functional code. By adhering to modern scoping rules (`let`/`const`) and understanding how closures retain environmental context, developers can write code that is robust, efficient, and highly manageable.

# Asynchronous Programming in JavaScript: Promises and Async/Await

## 1. Introduction to Asynchronous Programming

Asynchronous programming in JavaScript is a method of handling operations that take time (like fetching data from an API, reading files, or setting timers) without blocking the execution of the main thread.

In a single-threaded environment like JavaScript, if an operation were synchronous, the entire program would halt while waiting for the operation to complete. Asynchronous programming allows the program to initiate a task and continue executing other tasks while waiting for the result, improving the responsiveness and efficiency of applications.

## 2. The Problem: Synchronous Blocking

JavaScript is inherently single-threaded. If we rely solely on synchronous operations, a long-running task would block the entire program, leading to a frozen user interface (UI) and poor performance.

**Synchronous Example (Blocking):**
```javascript
// This operation blocks the thread until it completes
const data = longRunningOperation();
console.log(data);
```

## 3. Promises: The Foundation of Asynchronicity

Promises are objects that represent the eventual completion (or failure) of an asynchronous operation and its resulting value. They provide a clean, structured way to manage asynchronous results.

### 3.1. Promise States

A Promise exists in one of three states:

1.  **Pending:** The initial state; the operation has neither been fulfilled nor rejected.
2.  **Fulfilled (Resolved):** The operation completed successfully, and the Promise has a resulting value.
3.  **Rejected:** The operation failed, and the Promise has a reason for the failure (an error).

### 3.2. Promise Methods

| Method | Description |
| :--- | :--- |
| `.then(onFulfilled, onRejected)` | Used to handle the successful result or failure of the Promise. |
| `.catch(onRejected)` | A shorthand for `.then(null, onRejected)`, used specifically for error handling. |
| `.finally(onFinally)` | Used to execute code regardless of whether the Promise was fulfilled or rejected (useful for cleanup). |

### 3.3. Example: Using Promises

```javascript
function fetchData() {
    return new Promise((resolve, reject) => {
        // Simulate an asynchronous operation (e.g., API call)
        setTimeout(() => {
            const success = true; // Change to false to simulate failure
            if (success) {
                resolve("Data successfully fetched!");
            } else {
                reject("Error: Failed to fetch data.");
            }
        }, 2000);
    });
}

// Consuming the Promise
fetchData()
    .then(result => {
        console.log("Success:", result); // Output: Data successfully fetched!
    })
    .catch(error => {
        console.error("Failure:", error); // Output: Error: Failed to fetch data.
    })
    .finally(() => {
        console.log("Operation complete.");
    });
```

## 4. Async/Await: Syntactic Sugar over Promises

`async/await` is syntactic sugar built on top of Promises. It allows asynchronous code to be written in a manner that looks and behaves like synchronous code, making it significantly easier to read, write, and debug.

### 4.1. The `async` Keyword

The `async` keyword is used to declare a function as asynchronous. An `async` function always returns a Promise implicitly.

### 4.2. The `await` Keyword

The `await` keyword can only be used inside an `async` function. It pauses the execution of the function until the Promise it precedes is settled (resolved or rejected) and then returns the resolved value.

### 4.3. Example: Using Async/Await

Using the previous Promise example, we can rewrite it using `async/await`:

```javascript
async function loadData() {
    try {
        // 'await' pauses execution until fetchData resolves the Promise
        const result = await fetchData();
        console.log("Async/Await Success:", result);
        return result;
    } catch (error) {
        // Standard try...catch handles Promise rejections
        console.error("Async/Await Failure:", error);
        // If we re-throw, the promise returned by loadData() will reject.
        throw error;
    } finally {
        console.log("Async/Await Operation complete.");
    }
}

loadData();
```

## 5. The JavaScript Event Loop (The Mechanism)

To understand how asynchronous operations work in JavaScript, one must understand the Event Loop, which manages the interaction between the Call Stack, the Web APIs, and the Callback Queue.

1.  **Call Stack:** Where synchronous code execution happens.
2.  **Web APIs (or Node.js APIs):** Environment functions (like `setTimeout`, DOM events, or AJAX calls) that handle the actual asynchronous work outside the main thread.
3.  **Callback Queue (or Microtask Queue):** When an asynchronous operation finishes, its callback function is placed here, waiting for the Call Stack to be empty.
4.  **Event Loop:** Continuously monitors the Call Stack and the Callback Queue. When the Call Stack is empty, the Event Loop takes the first item from the Queue and pushes it onto the Call Stack for execution.

**How Promises fit in:** When an API call is made (e.g., `fetch()`), the request is handed off to the Web APIs. The main thread continues running. When the data finally arrives, the associated Promise moves its callback into the Microtask Queue. The Event Loop picks up this callback when the Call Stack is clear, ensuring non-blocking execution.

## 6. Best Practices for Asynchronous Code

### 6.1. Prefer Async/Await

For modern codebases, `async/await` is strongly preferred over deeply nested `.then()` chains because it improves readability and reduces the risk of errors (especially with complex error handling).

### 6.2. Robust Error Handling

Always wrap asynchronous code in `try...catch` blocks when using `await` to properly handle rejected Promises.

### 6.3. Avoid Callback Hell

Never rely on deeply nested callbacks (Callback Hell). Use Promises or `async/await` to chain operations sequentially, ensuring linear flow and manageable error propagation.

### 6.4. Managing Concurrency

Be mindful of concurrency. If you initiate many simultaneous requests, ensure you manage the potential overload on the system (e.g., implementing rate limiting or using techniques like `Promise.all()` or `Promise.allSettled()` to handle multiple tasks in parallel).

## 7. Advanced Promise Methods

For handling multiple asynchronous operations concurrently:

*   **`Promise.all(iterable)`:** Waits for all Promises in the iterable to resolve. If any Promise rejects, `Promise.all()` immediately rejects with the reason of the first rejection.
*   **`Promise.race(iterable)`:** Returns a Promise that settles as soon as one of the Promises in the iterable settles (either resolves or rejects).
*   **`Promise.allSettled(iterable)`:** Waits for all Promises to complete, regardless of success or failure. It returns an array of objects describing the outcome of each Promise.
*   **`Promise.any(iterable)`:** Returns a Promise that resolves as soon as *at least one* of the Promises resolves.

## 8. Conclusion

Asynchronous programming, powered by Promises and syntactic sugar provided by `async/await`, is fundamental to writing efficient, scalable, and responsive JavaScript applications. By mastering the concept of the Event Loop and employing structured methods for managing asynchronous flows, developers can effectively handle time-consuming operations without blocking the main thread, leading to cleaner and more maintainable code.

# Error Handling (Try/Catch) in JavaScript

## 1. Introduction to Error Handling

Error handling is a critical process in programming that allows a script to manage unexpected conditions (errors or exceptions) that occur during execution. Without proper error handling, an application can crash abruptly, leading to poor user experience and potential security vulnerabilities.

In JavaScript, errors are objects that signal that something has gone wrong during the execution of the code. The primary mechanism for managing these errors is the `try...catch...finally` block.

## 2. Core Concepts: Try, Catch, and Throw

### 2.1. The `try` Block
The `try` block contains the code that is potentially risky. If an error occurs within this block, execution immediately stops, and control is transferred to the corresponding `catch` block.

### 2.2. The `catch` Block
The `catch` block executes only if an error is thrown within the `try` block. It receives the error object as an argument (commonly named `error` or `e`), which provides details about the error.

```javascript
try {
    // Code that might throw an error
    let result = 10 / 0;
} catch (error) {
    // Code executed if an error occurs
    console.error("An error occurred:", error.message);
}
```

### 2.3. The `throw` Statement
The `throw` statement is used to manually generate an error. This is useful when you detect an invalid state or condition in your code and need to signal an error to the calling scope.

```javascript
function checkAge(age) {
    if (age < 18) {
        // Manually throw an error
        throw new Error("Access Denied: User must be 18 or older.");
    }
    console.log("Access granted.");
}

try {
    checkAge(16);
} catch (e) {
    console.log("Caught the error:", e.message);
}
```

## 3. The `finally` Block

The `finally` block is optional, but highly useful. It contains code that *must* be executed regardless of whether an error occurred or not. This block is typically used for cleanup operations, such as closing files, releasing database connections, or resetting variables.

```javascript
try {
    // Risky operation
    let data = JSON.parse('invalid json');
} catch (error) {
    console.error("Parsing failed:", error.message);
} finally {
    // This code always runs, whether an error occurred or not
    console.log("Execution attempt complete.");
}
```

## 4. Handling Synchronous Errors

Synchronous errors occur during the direct execution of the code line by line. The standard `try...catch` structure is ideal for handling these.

### Example: Synchronous Error Handling

```javascript
function divide(a, b) {
    if (b === 0) {
        throw new Error("Division by zero is not allowed.");
    }
    return a / b;
}

try {
    const result = divide(10, 0);
    console.log("Result:", result);
} catch (err) {
    console.error("Error caught:", err.message);
}
// Output: Error caught: Division by zero is not allowed.
```

## 5. Advanced Error Handling: Asynchronous Operations

In modern JavaScript, many operations (like fetching data from an API, timers, or file operations) are asynchronous. Standard `try...catch` blocks do not automatically catch errors thrown inside asynchronous functions (like Promises or `setTimeout`).

### 5.1. Handling Errors with Promises (`.catch()`)

When dealing with Promises, errors are handled by attaching a `.catch()` handler to the Promise chain.

```javascript
function fetchData() {
    return new Promise((resolve, reject) => {
        // Simulate a network failure
        reject(new Error("Network connection failed."));
    });
}

fetchData()
    .then(data => {
        console.log("Data received:", data);
    })
    .catch(error => {
        // This catches the rejection (error) from the Promise
        console.error("Promise Error:", error.message);
    });
```

### 5.2. Handling Errors with `async/await`

The `async/await` syntax simplifies asynchronous error handling by allowing the use of standard `try...catch` blocks around `await` calls.

```javascript
async function loadData() {
    try {
        // 'await' pauses execution until the promise resolves or rejects
        const response = await fetch('invalid-url'); 
        const data = await response.json();
        console.log("Data loaded successfully.");
    } catch (error) {
        // This catches any error thrown during the await process
        console.error("Failed to load data:", error.message);
    }
}

loadData();
```

## 6. Best Practices for Robust Error Handling

### 6.1. Be Specific When Catching
Avoid catching generic errors if possible. Catching a specific error type allows you to handle different failure scenarios differently.

**Bad Practice:**
```javascript
try {
    // ...
} catch (e) { /* Catches everything */ }
```

**Good Practice:**
```javascript
try {
    // ...
} catch (TypeError) {
    console.error("Operation failed due to incorrect data type.");
} catch (ReferenceError) {
    console.error("A required variable was not defined.");
}
```

### 6.2. Log Detailed Information
When an error is caught, log the full error object or at least the stack trace to aid in debugging.

```javascript
try {
    // ...
} catch (error) {
    console.error("Full Error Details:", error); // Prints the full object, including stack trace
}
```

### 6.3. Don't Swallow Errors
Never use an empty `catch` block (`catch(e) {}`). This practice masks the error, making debugging impossible, and allows the program to continue in an unknown state. Always handle or log the error.

### 6.4. Re-throwing Errors
If you catch an error but cannot fully resolve it, you can re-throw a new, more context-specific error.

```javascript
try {
    // Attempt a complex operation
} catch (originalError) {
    // Wrap the error with context before re-throwing
    throw new Error(`Critical failure during payment: ${originalError.message}`);
}
```

# Modules (Import/Export) in JavaScript

## 1. Introduction to JavaScript Modules

Modules are a fundamental feature in modern JavaScript (ES6+) that provide a standardized way to organize code, manage dependencies, and encapsulate functionality. Modules allow developers to break down large applications into smaller, manageable, and reusable units.

### 1.1 Why Use Modules?

*   **Encapsulation:** Modules hide internal implementation details (variables, functions) from the rest of the application, preventing naming collisions and improving code security.
*   **Reusability:** Code within a module can be easily imported and reused in other files or projects.
*   **Maintainability:** Breaking code into logical units simplifies debugging and maintenance.
*   **Dependency Management:** Modules explicitly declare what they need (dependencies) and what they provide (exports), making the flow of data clear.

### 1.2 Module Systems in JavaScript

There are two primary module systems in the JavaScript ecosystem:

1.  **ES Modules (ESM):** The official, standardized module system used natively in modern browsers and Node.js. It uses the `import` and `export` keywords.
2.  **CommonJS (CJS):** The module system commonly used in Node.js. It uses synchronous loading mechanisms (`require()` and `module.exports`).

***Note:*** For browser-based development and modern Node.js applications, **ES Modules (ESM)** are the preferred standard.

## 2. ES Modules (ESM) Deep Dive

ES Modules rely on static analysis of the code (which imports and exports are used) to determine the dependency graph, which is crucial for optimizing the build process (tree-shaking).

### 2.1 Exporting Data

Modules use the `export` keyword to make variables, functions, or classes available to other modules. There are two primary ways to export:

#### a) Named Exports

Named exports allow exporting multiple values from a single module. These must be imported using the exact name they were exported under.

```javascript
// file: math.js
export const PI = 3.14159;
export function add(a, b) {
  return a + b;
}
```

#### b) Default Export

The `export default` statement specifies a single, primary export from the module. A module can only have one default export. This is typically used for the main entity (like a class or a primary function) of the file.

```javascript
// file: calculator.js
const add = (a, b) => a + b;

export default add; // Exporting the 'add' function as the default export
```

### 2.2 Importing Data

Modules use the `import` keyword to bring external exports into the current scope.

#### a) Importing Named Exports

Named exports require curly braces `{}` and use the exported name.

```javascript
// file: main.js
import { PI, add } from './math.js';

console.log(PI);      // 3.14159
console.log(add(5, 3)); // 8
```

#### b) Importing the Default Export

The default export can be imported using any local name chosen by the developer.

```javascript
// file: main.js
import calculator from './calculator.js'; // 'calculator' is the local name chosen for the default export

console.log(calculator(10, 5)); // 15
```

### 2.3 Module Paths and Types

When importing files, the path specified in the `import` statement determines the type of module being loaded.

| Import Type | Purpose | Example |
| :--- | :--- | :--- |
| **Relative Path** | Imports from files within the same directory. | `import { func } from './utils.js';` |
| **Absolute Path** | Imports from the root of the project structure. | `import { func } from '../components/utils.js';` |
| **Bare Specifier** | Used for importing entire modules (often requires the export to be default). | `import utils from './utils.js';` |

## 3. Advanced Module Concepts

### 3.1 Dynamic Imports (Asynchronous Loading)

For applications where modules need to be loaded only when they are needed (e.g., loading components or handling conditional routes), **dynamic imports** are used. This returns a Promise, allowing for asynchronous loading.

```javascript
// Asynchronous import
async function loadModule(moduleName) {
  // The path must be a string literal
  const module = await import(`./${moduleName}.js`);
  console.log('Module loaded successfully:', module);
  // Use the exported content
  module.default();
}

loadModule('math');
```

### 3.2 Tree Shaking

Tree shaking is an optimization process used by modern module bundlers (like Webpack or Rollup). Because ESM exports are statically defined, bundlers can analyze the dependency graph and eliminate any exported code that is never imported, resulting in smaller, more optimized production bundles.

### 3.3 Handling Dependencies

When dealing with large projects, modules often rely on a separate package manager (like npm) to handle the complex installation and dependency linking process, abstracting away the file-system import details.

## 4. Best Practices for Module Development

### 4.1 Consistency is Key

*   **Choose One System:** Stick to ES Modules for modern front-end and general JavaScript development. Avoid mixing ESM and CommonJS unnecessarily.
*   **Naming Conventions:** Use descriptive file and variable names.

### 4.2 Managing Dependencies

*   **Use Package Managers (npm/yarn):** For external libraries, always use package managers to handle versioning and dependency installation, rather than manually managing file paths.
*   **Avoid Circular Dependencies:** Circular dependencies (where Module A imports Module B, and Module B imports Module A) can lead to complex runtime errors and difficult-to-debug state issues. Design modules to be decoupled.

### 4.3 Code Structure

*   **Single Responsibility Principle (SRP):** Each module should ideally handle one specific task or domain.
*   **Clear Exports:** Be explicit about what data is being exported. Avoid exporting complex objects if only a single property is needed.

## 5. Example Implementation

This example demonstrates how two separate ES modules interact.

### Module 1: `dataProcessor.js` (Exporter)

```javascript
// dataProcessor.js

/**
 * Calculates the square of a number.
 * @param {number} x
 * @returns {number}
 */
export function square(x) {
  return x * x;
}

/**
 * Returns a predefined base value.
 */
export const BASE_VALUE = 100;
```

### Module 2: `app.js` (Importer)

```javascript
// app.js

// Import named exports using curly braces
import { square, BASE_VALUE } from './dataProcessor.js';

console.log("--- Application Start ---");

// Use the imported functions and constants
const num = 7;
const squared = square(num);
const result = BASE_VALUE + squared;

console.log(`The square of ${num} is: ${squared}`);
console.log(`The final result is: ${result}`);

// Output:
// --- Application Start ---
// The square of 7 is: 49
// The final result is: 149
```

# DOM Manipulation in JavaScript

## 1. Introduction to the DOM

### 1.1 What is the Document Object Model (DOM)?

The Document Object Model (DOM) is a programming interface for HTML and XML documents. It represents the logical structure of a document as a tree of nodes, where every HTML tag, attribute, and text is a node.

JavaScript uses the DOM to interact with and dynamically modify the content, structure, and style of web pages. It acts as the bridge between the static HTML structure and the dynamic behavior created by scripts.

### 1.2 Why is DOM Manipulation Important?

DOM manipulation allows developers to:
*   **Dynamically Change Content:** Update text, HTML structure, and attributes based on user interaction or data.
*   **Manage Styling:** Apply or change CSS styles based on conditions.
*   **Handle Events:** Respond to user actions (clicks, input, key presses).
*   **Create Interactivity:** Build complex, responsive single-page applications (SPAs) where the interface changes without a full page reload.

## 2. Selecting Elements in the DOM

Before manipulation can occur, the elements must be selected from the DOM tree.

### 2.1 Methods for Element Selection

| Method | Description | Use Case |
| :--- | :--- | :--- |
| `document.getElementById('id')` | Returns the element with the specified ID. | Selecting a single, unique element. |
| `document.querySelector('selector')` | Returns the *first* element that matches the specified CSS selector (e.g., class, ID, tag). | Selecting a single element using CSS syntax. |
| `document.querySelectorAll('selector')` | Returns a *NodeList* (a static list) of all elements that match the specified CSS selector. | Selecting multiple elements (e.g., all list items). |
| `document.getElementsByClassName('className')` | Returns an HTMLCollection of all elements with the specified class. | Selecting elements based on a common class. |

### 2.2 Example: Selection

```javascript
// Selecting by ID
const header = document.getElementById('main-title');

// Selecting by CSS Selector (first match)
const firstParagraph = document.querySelector('.content p');

// Selecting multiple elements
const allButtons = document.querySelectorAll('button');

console.log(header); // DOMElement
console.log(allButtons.length); // Number of elements found
```

## 3. Manipulating Elements

Once an element is selected, JavaScript can modify its content, structure, and appearance.

### 3.1 Modifying Content

| Property/Method | Description | Example |
| :--- | :--- | :--- |
| `.textContent` | Gets or sets the textual content of an element and its descendants. Ignores HTML tags. | `element.textContent = "New Text";` |
| `.innerHTML` | Gets or sets the HTML content (including tags) of an element. | `element.innerHTML = "<strong>Bold Text</strong>";` |
| `.value` | Gets or sets the value of form elements (like `<input>`, `<textarea>`). | `inputElement.value = "user input";` |

**Caution:** When using `.innerHTML`, be extremely careful about injecting user-provided data, as it introduces **Cross-Site Scripting (XSS)** vulnerabilities if not properly sanitized. Use `.textContent` for plain text insertion.

### 3.2 Modifying Styles

Styles are manipulated using the `.style` property, which allows inline style manipulation. CSS property names are converted to camelCase in JavaScript.

```javascript
const box = document.getElementById('myBox');

// Changing a single style property
box.style.backgroundColor = 'lightblue';
box.style.fontSize = '16px';
box.style.border = '2px solid blue';
```

**Best Practice:** For complex, maintainable styling, it is generally better practice to manipulate classes via the `.classList` property rather than setting individual inline styles.

```javascript
// Preferred method for style management
box.classList.add('highlight');
box.classList.remove('hidden');
```

### 3.3 Modifying Structure (Adding and Removing Elements)

To change the overall structure of the page, we use methods to insert, remove, or move elements within the DOM tree.

| Method | Description | Example |
| :--- | :--- | :--- |
| `.appendChild(child)` | Adds an element (child node) to the end of the selected element. | `parentElement.appendChild(newElement);` |
| `.prepend(child)` | Adds an element to the beginning of the selected element. | `parentElement.prepend(newElement);` |
| `.removeChild(child)` | Removes a specified child node from the parent. | `parentElement.removeChild(childToRemove);` |
| `.remove()` | (Modern browsers) Removes the element to which the method is called. | `childToRemove.remove();` |

### 3.4 Example: Structure Manipulation

```javascript
// 1. Create a new element
const newListItem = document.createElement('li');
newListItem.textContent = 'New Item Added Dynamically';
newListItem.classList.add('dynamic-item');

// 2. Select the parent element (e.g., an unordered list)
const ul = document.getElementById('myList');

// 3. Append the new element to the list
ul.appendChild(newListItem);
```

## 4. Event Handling in DOM

Event handling connects user interactions to JavaScript functions, enabling dynamic behavior.

### 4.1 Event Object and Listeners

Events occur when a user interacts with an element (e.g., mouse click, key press). Event handling is done by attaching an **event listener** to an element.

*   **`addEventListener(event, handler)`:** The standard and most flexible way to handle events.
*   **Event Object:** The function passed as the handler receives an `event` object containing details about the event that occurred.

### 4.2 Example: Event Listener

```javascript
const button = document.getElementById('clickMe');

// Attach an event listener for the 'click' event
button.addEventListener('click', function(event) {
    // The event object contains information about the click
    console.log('Button was clicked!');
    
    // Example of manipulating the DOM upon click
    document.body.style.backgroundColor = 'yellow';
});
```

## 5. Best Practices for Efficient DOM Manipulation

DOM manipulation can be computationally expensive, especially on large documents. Following these best practices ensures performance and maintainability.

### 5.1 Minimize Direct DOM Access

*   **Batch Operations:** Group multiple DOM changes together rather than making many small, sequential operations.
*   **Avoid Excessive Reflows/Repaints:** Reflows (recalculating the geometry of elements) and repaints (redrawing the pixels) are performance bottlenecks. Avoid reading layout properties (like `offsetWidth`, `getComputedStyle()`) inside tight loops.

### 5.2 Use Efficient Selection

*   **Favor CSS Selectors:** Use powerful CSS selectors (`querySelector`, `querySelectorAll`) rather than traversing the DOM repeatedly with complex nested loops.
*   **Cache References:** Store references to frequently accessed elements in variables to avoid repeated costly lookups.

### 5.3 Frameworks and Libraries

For large, complex applications, direct DOM manipulation becomes unwieldy. Modern frameworks like **React, Vue, and Angular** manage the DOM for you through a Virtual DOM, abstracting away most of the manual manipulation and improving performance significantly.

### 5.4 Deferring Operations

If you are performing a large number of operations, consider using asynchronous operations or `requestAnimationFrame` to delay rendering updates, allowing the browser to process other tasks in the meantime.

# ES6 Features: Destructuring and Spread Operator in JavaScript

## 1. Introduction to ES6 (ECMAScript 2015)

ES6 introduced a massive set of syntactic improvements and features to JavaScript, making the language cleaner, more powerful, and easier to manage. Among the most impactful additions are **Destructuring Assignment** and the **Spread Operator**, which significantly simplify working with complex data structures (objects and arrays).

This report details the concepts, syntax, and practical applications of these two fundamental ES6 features.

## 2. Destructuring Assignment

Destructuring is a feature that allows you to unpack values from arrays or properties from objects into distinct, distinct variables. It enables cleaner, more readable code by reducing the need for repetitive property access.

### 2.1. Destructuring Objects

Destructuring objects is used to extract properties from an object and assign them to variables with the same name.

#### Syntax and Concept

```javascript
const user = { name: 'Alice', age: 30, city: 'New York' };

// Destructuring extraction
const { name, age } = user;

console.log(name); // Output: Alice
console.log(age);  // Output: 30
```

#### Advanced Object Destructuring

**1. Renaming Variables:** Use the `as` keyword to rename the extracted variables if the property name conflicts with the desired variable name.

```javascript
const user = { name: 'Alice', age: 30 };
const { name: userName, age: userAge } = user;

console.log(userName); // Output: Alice
console.log(userAge);  // Output: 30
```

**2. Setting Default Values:** Assign default values to properties if they are missing from the object, preventing `undefined` errors.

```javascript
const settings = { theme: 'dark' };

// If 'fontSize' is missing, it defaults to 16
const { theme, fontSize = 16 } = settings;

console.log(theme);  // Output: dark
console.log(fontSize); // Output: 16
```

### 2.2. Destructuring Arrays

Destructuring arrays allows you to extract elements based on their position.

#### Syntax and Concept

```javascript
const colors = ['red', 'green', 'blue'];

// Standard array destructuring (extraction by position)
const [primary, secondary, tertiary] = colors;

console.log(primary);  // Output: red
console.log(secondary); // Output: green
```

#### Rest Element in Array Destructuring

The `...` operator (rest element) can be used to gather the remaining elements into a new array.

```javascript
const numbers = [1, 2, 3, 4, 5];
const [first, second, ...restOfNumbers] = numbers;

console.log(first);        // Output: 1
console.log(second);       // Output: 2
console.log(restOfNumbers); // Output: [3, 4, 5]
```

## 3. The Spread Operator (`...`)

The Spread Operator is a powerful feature that allows an iterable (like an array or string) to be expanded into its individual elements. It is used to simplify operations involving copying, combining, and manipulating data structures.

### 3.1. Spread Operator for Arrays

The spread operator is invaluable for combining or duplicating arrays without using manual loops or the `concat()` method.

#### Syntax and Concept

```javascript
const arr1 = [1, 2, 3];
const arr2 = [4, 5, 6];

// Combining arrays
const combinedArray = [...arr1, ...arr2];
console.log(combinedArray); // Output: [1, 2, 3, 4, 5, 6]

// Cloning an array (shallow copy)
const copyArray = [...arr1];
console.log(copyArray); // Output: [1, 2, 3]
```

### 3.2. Spread Operator for Objects

When used with objects, the spread operator allows you to easily copy properties from one object into another, facilitating immutability (avoiding direct mutation).

#### Syntax and Concept

```javascript
const userDetails = { id: 101, name: 'Bob' };

// Merging objects (creating a new object)
const userProfile = { ...userDetails, email: 'bob@example.com' };

console.log(userProfile);
/* Output:
{
  id: 101,
  name: 'Bob',
  email: 'bob@example.com'
}
*/
```

#### Nested Object Merging (Spread within Spread)

The spread operator excels at merging deeply nested objects.

```javascript
const baseConfig = { port: 8080, timeout: 5000 };
const devConfig = { timeout: 10000, debug: true };

// Merge baseConfig, overriding 'timeout' and adding 'debug'
const finalConfig = { ...baseConfig, ...devConfig };

console.log(finalConfig);
/* Output:
{
  port: 8080,
  timeout: 10000, // Overridden value
  debug: true
}
*/
```

### 3.3. Spread Operator in Function Calls

The spread operator can unpack array elements into function arguments, making function calls much cleaner.

```javascript
const scores = [90, 85, 92];

// Instead of scores.apply(null, scores), we use spread
const sum = (a, b, c) => a + b + c;
const result = sum(...scores); // Calls sum(90, 85, 92)

console.log(result); // Output: 267
```

## 4. Best Practices and Use Cases

### 4.1. When to Use Destructuring

*   **Parameter Handling:** Extracting necessary parameters from a function call.
*   **Configuration Objects:** Extracting settings from API responses or configuration files.
*   **Readability:** Replacing verbose property lookups (e.g., `user.name`) with cleaner variable assignments.

### 4.2. When to Use the Spread Operator

*   **Immutability:** Creating new objects or arrays based on existing ones, avoiding mutation of the original data (essential in frameworks like React).
*   **Array Concatenation:** Easily joining or merging multiple arrays.
*   **Function Arguments:** Passing array elements directly as arguments to a function.
*   **Conditional Logic:** Dynamically creating objects or arrays based on existing data.

### 4.3. Performance Considerations

Both destructuring and the spread operator are syntactic sugar; they do not introduce runtime performance overhead compared to traditional methods. They simply provide a cleaner, more concise way to perform the same underlying operations.

## 5. Summary Table

| Feature | Primary Purpose | Syntax Example | Core Benefit |
| :--- | :--- | :--- | :--- |
| **Destructuring** | Extracting values from objects/arrays. | `const { a, b } = obj;` | Reduces boilerplate code; improves readability. |
| **Spread Operator** | Expanding iterable elements into a structure. | `const newArr = [...arr1, ...arr2];` | Simplifies array/object copying and merging; promotes immutability. |

# Type Coercion in JavaScript: A Detailed Report

## 1. Introduction to Type Coercion

Type coercion in JavaScript is the process by which values of different data types are converted or coerced into a common data type during an operation. This mechanism is fundamental to how JavaScript handles comparisons, arithmetic operations, and type juggling, often leading to unexpected results if not understood properly.

JavaScript is a dynamically and weakly typed language, meaning it does not strictly enforce type checking at runtime. Type coercion allows the language to perform operations between seemingly incompatible types (e.g., comparing a string and a number) by converting one or both operands into a common type.

## 2. Key Concepts

### 2.1 Implicit Coercion
Implicit coercion occurs automatically, without the programmer explicitly writing conversion functions. JavaScript handles the conversion internally when an operation is performed.

*   **Example:** When using the loose equality operator (`==`) to compare a string and a number, JavaScript implicitly converts the string to a number before the comparison takes place.

### 2.2 Explicit Coercion
Explicit coercion occurs when the programmer intentionally forces a type conversion using built-in functions (e.g., `String()`, `Number()`, `parseInt()`, `parseFloat()`) or mathematical operators.

### 2.3 Type Juggling
Type juggling is the general term for the flexibility of JavaScript to treat different types as a single type during an operation.

## 3. Coercion Mechanisms

Type coercion primarily happens in two main contexts: comparison operators and arithmetic operators.

### 3.1 Coercion in Comparison Operations

Comparison operators rely heavily on type coercion to determine the outcome of a boolean expression.

#### A. Loose Equality (`==`)
The `==` operator performs **type coercion**. It attempts to convert both operands to a common type (usually a Number) before making the comparison.

*   **Behavior:** Allows comparisons between different types.
*   **Pitfall:** Can lead to logical errors because the conversion rules are complex and context-dependent.

#### B. Strict Equality (`===`)
The `===` operator performs **strict equality**. It checks both the value *and* the data type without performing any type conversion.

*   **Behavior:** If the types are different, the comparison immediately returns `false`.
*   **Best Practice:** Using `===` is strongly recommended in modern JavaScript development to avoid unexpected coercion bugs.

### 3.2 Coercion in Arithmetic Operations

Arithmetic operations (`+`, `-`, `*`, `/`, `%`, etc.) involve complex rules for converting operands into numbers.

*   **String to Number Conversion:** If one operand is a string, JavaScript attempts to parse the string into a number.
    *   If the string starts with a number (e.g., `"10" * 2`), the coercion works successfully.
    *   If the string is non-numeric (e.g., `"hello" * 2`), the result is `NaN` (Not a Number).
*   **Type Promotion:** When mixing types, JavaScript generally promotes the operands to the highest-ranking type present (often Number).

## 4. Detailed Examples

### Example 1: Loose Equality vs. Strict Equality

```javascript
let num = 10;
let str = "10";

// Loose Equality (Coerces 'str' to number)
console.log(num == str); // true (10 == 10)

// Strict Equality (Does not coerce types)
console.log(num === str); // false (Number is not strictly equal to String)
```

### Example 2: Arithmetic Coercion

```javascript
let a = 5;
let b = "3"; // String type

// Addition operation (String coercion)
let sum = a + b; // JavaScript converts 'b' (string) to 3, then performs addition.
console.log(sum); // 8 (Number)

// Multiplication operation (String coercion/parsing)
let product = a * b;
console.log(product); // 15 (The string "3" is coerced to the number 3)

// Invalid coercion
let result = "5" * "hello";
console.log(result); // NaN (Cannot coerce "hello" into a number)
```

## 5. Best Practices and Mitigation

To write predictable, robust, and maintainable JavaScript code, developers should minimize reliance on implicit type coercion.

### 5.1 Prioritize Strict Equality (`===`)
Always use `===` and `!==` when comparing values. This eliminates the ambiguity introduced by type juggling.

### 5.2 Use Explicit Type Conversion
If you need to perform an operation between variables of different types, explicitly convert one to the desired type using methods like `Number()` or `parseInt()` to make the intent clear:

```javascript
let value = "42";
let numberValue = Number(value); // Explicit conversion
let newSum = 5 + numberValue;     // 9 (Clear conversion path)
```

### 5.3 Avoid Unexpected Operator Side Effects
Be cautious when using arithmetic operators (`+`, `-`) on mixed data types, as the coercion rules can lead to confusing results (especially involving `null`, `undefined`, or non-numeric strings), potentially masking bugs.

### 5.4 Type Checking Functions
For complex data validation, rely on explicit type checking rather than relying on coercion results:

```javascript
if (typeof variable === 'number' && variable > 0) {
    // Safely handle only numeric data
}
```

## 6. Conclusion

Type coercion is an inherent feature of JavaScript’s dynamic nature, enabling flexibility but introducing complexity. Understanding the difference between loose equality (`==`) and strict equality (`===`), and mastering the implicit conversion rules for arithmetic operations, is essential. By adopting the best practices of using strict comparisons and explicit type casting, developers can write code that is less prone to subtle, runtime errors stemming from unexpected type conversions.
