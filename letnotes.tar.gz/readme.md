**Research Bot**  
A lightweight Python project that generates a research report for a given topic using an Ollama-powered language model, writes the report in Markdown, and converts it to a PDF.  
**Overview**  
This project takes a research topic from the user, asks an LLM for the main topic headings, writes a structured Markdown report, and then exports it to a PDF using WeasyPrint.  
It is designed to help quickly create topic-based research documents with a clean output format.  
**Features**  
- Accepts a research topic from the command line  
- Uses Ollama to generate headings and detailed sections  
- Builds a Markdown report automatically  
- Converts the Markdown file to PDF  
- Stores generated files in dedicated output folders  
**Project Structure**  
```  
Research_bot/  
 ├── main.py  
 ├── readme.txt  
 ├── data/  
 │   └── template.txt  
 ├── files/  
 ├── src/  
 │   ├── md_converter.py  
 │   ├── prompts.py  
 │   └── report_gen.py  
 └── requirements.txt (if added later)  
   
```  
**How It Works**  
1. `main.py` prompts the user for a research topic.  
2. `src/report_gen.py` calls the model to generate important topic headings.  
3. `src/prompts.py` contains the prompt templates for both the table-of-contents generation and detailed section generation.  
4. The generated Markdown file is saved under `files/`.  
5. `src/md_converter.py` converts the Markdown content to PDF and saves it under `Reports/`.  
**Requirements**  
Install the following dependencies:  
```  
pip install ollama markdown weasyprint  
   
```  
You also need Ollama installed and running locally with a model available, such as:  
```  
ollama pull gemma4:e2b  
   
```  
**Run the Project**  
From the project root, run:  
```  
python main.py  
   
```  
Then enter a research topic when prompted, for example:  
```  
Please provide the research topic: machine learning  
   
```  
**Output**  
- Markdown output is generated in the `files/md_file` folder.  
- PDF output is generated in the `files/pdf_file` folder.  
**Notes**  
- The default model is configured in `src/report_gen.py` as `gemma4:e2b`.  
- The template for PDF styling is stored in `data/template.txt`.  
- Ensure the output directories exist before running the script, or create them manually if needed.  
**Example**  
A typical workflow might look like this:  
```  
Please provide the research topic: cybersecurity  
   
```  
The program will create a report around the topic and save a PDF version in `files/cybersecurity.pdf`.  
**License**  
This project does not currently include a license file. Add a license if you plan to distribute or share it publicly.  
