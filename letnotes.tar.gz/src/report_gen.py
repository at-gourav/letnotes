import ollama 
import os
import ast
import src.prompts as prompts
import src.gemini as gemini

model = "gemma4:e2b"

def brain(prompt): # feeds input to ollama and returns the output
    response = ollama.chat(model=model, messages=[{"role": "user", "content": prompt}])
    return response

def ReportGenerator(title:str) ->str:

    title = title
    output_path = f"files/md_file/{title}.md"

    topics =prompts.get_topics(title)  #create prompt for generating topic headings


    topic_names = brain(topics)    #output from gemini for the topic headings prompt

    topic_list = ast.literal_eval(topic_names.message.content)      #Converts output string to a list of string


    # Writing the Table of contents to the output file
    with open(output_path, "w") as topic_file:
        topic_file.write(f"# {title} Report\n\n")
        topic_file.write(f"## Table of Contents\n")
        for i, topic in enumerate(topic_list):
            topic_file.write(f"{i + 1}. {topic}\n")

    # wrting the detailed report for each topic to the output file
    for i, topic in enumerate(topic_list):
        topic_prompt = prompts.get_detail(title, topic)
        theory_response = brain(topic_prompt)
        with open(output_path, "a") as file:
            file.write(f'''\n{theory_response.message.content}\n''')
        print(f"{i+1}. {topic} ////done////")

    return output_path






