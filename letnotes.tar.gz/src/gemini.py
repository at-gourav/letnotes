from google import genai

api_key = "AQ.Ab8RN6LIjUd388uIIy1JSuBwknM1S3lfW-4DultQ8OaBSsW0FA"

client = genai.Client(api_key=api_key)
chat = client.chats.create(model="gemini-3.6-flash")

# # First turn
# response1 = chat.send_message("Hello! I live in Paris.")
# print(f"Gemini: {response1.text}")

# # Second turn (Gemini retains the context that you live in Paris)
# response2 = chat.send_message("What is the weather usually like where I live?")
# print(f"Gemini: {response2.text}")


def brain(prompt): # feeds input to Gemini and returns the output
    response = chat.send_message(prompt)
    return response.text



# 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