def get_topics(field: str) -> str:
    """Returns the prompt for generating topic headings."""
    return f"""What are the core building blocks / fundamental concepts that show up in almost every {field} project, regardless of the specific tool or specialization?
Give me just the list of topic headings — like a table of contents or index — with no explanations, descriptions, or examples. 
Format the output as a Python list of strings. format: ["topic1", "topic2", "topic3", ...]"""


def get_detail(field: str, topic: str) -> str:
    """Returns the prompt for generating a detailed report."""
    return f"""Generate a detailed report on the topic of "{topic}" in the context of {field}. 
Include key concepts, best practices, and relevant examples. 
Format the output as a structured report of MD format with headings and subheadings. 
Return only the report content and no commentary before or after."""