
# The client automatically picks up the OPENAI_API_KEY environment variable

api_key="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"

from openai import OpenAI

client = OpenAI(api_key=api_key)

response = client.responses.create(
    model="gpt-5.5",
    input="Explain machine learning to me in simple terms."
)

print(response.output_text)