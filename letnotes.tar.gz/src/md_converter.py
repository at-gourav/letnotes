import os
import markdown
from weasyprint import HTML


def md_to_pdf(input_md_path, output_pdf_path):

    input_path = input_md_path                 #input path
    output_path = output_pdf_path              #output path
    print(input_path)
    HTML_template = f""

    # 1. Read the Markdown file
    with open(input_path, "r", encoding="utf-8") as f:
        md_content = f.read()  
    
    # 2. Convert Markdown text to standard HTML
    html_content = markdown.markdown(md_content)

    
    # 3. Optional: Add a simple CSS sheet for clean margins and fonts
    with open("data/template.txt", "r", encoding="utf-8") as f:
        HTML_template = f.read()


    # 4. Generate the PDF
    final_html = HTML_template.format(html_content=html_content)
    
    HTML(string=final_html).write_pdf(output_path)

    return output_path


