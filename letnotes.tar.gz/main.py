import os
from src import report_gen
from src import md_converter


class Main:
    def __init__(self, research_topic):         

        """

        Initializes the Main class with the research topic, generates a report in Markdown format, and converts it to PDF.
        and returns the path to the generated PDF file.
        
        """

        self.title = research_topic

        self.generated_report = report_gen.ReportGenerator(self.title)

        self.output_pdf = md_converter.md_to_pdf(self.generated_report, f"files/pdf_file/{self.title}.pdf")

        print(f"Report generated and saved as PDF at: {self.output_pdf}")

if __name__ == "__main__":

    research_topic = input("Please provide the research topic: ")
    Main(research_topic)
        

        

